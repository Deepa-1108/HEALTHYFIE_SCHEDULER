package com.keepitsimplestudios.healthybattery;

public interface OnStateChangeListener {

    void onStateChanged(boolean newState, long newPeriod);

}
