package com.keepitsimplestudios.healthybattery.Definitions;

/**
 * Created by nunop on 29/01/2017.
 */

interface DefinitionsPresenter {

    void initializeElements();

    void saveElements();
}
